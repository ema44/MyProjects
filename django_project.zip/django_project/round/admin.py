from django.contrib import admin
from .models import Round

admin.site.register(Round)
