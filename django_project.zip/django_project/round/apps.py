from django.apps import AppConfig


class RoundConfig(AppConfig):
    name = 'round'
