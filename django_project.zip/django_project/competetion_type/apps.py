from django.apps import AppConfig


class CompetetionTypeConfig(AppConfig):
    name = 'competetion_type'
