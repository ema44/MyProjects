from django.contrib import admin
from .models import CompetetionType

admin.site.register(CompetetionType)
