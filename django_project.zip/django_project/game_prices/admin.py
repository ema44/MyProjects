from django.contrib import admin
from .models import GamePrice

admin.site.register(GamePrice)
