from django.apps import AppConfig


class GamePricesConfig(AppConfig):
    name = 'game_prices'
