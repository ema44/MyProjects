from django.contrib import admin
from .models import PaymentRecord

admin.site.register(PaymentRecord)
