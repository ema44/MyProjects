from django.apps import AppConfig


class PaymentRecordsConfig(AppConfig):
    name = 'payment_records'
