from django.apps import AppConfig


class ClubConfig(AppConfig):
    name = 'club'
