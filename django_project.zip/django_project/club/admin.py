from django.contrib import admin
from .models import Club

admin.site.register(Club)
