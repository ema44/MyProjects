from django.apps import AppConfig


class HomeOrAwayStatusConfig(AppConfig):
    name = 'home_or_away_status'
