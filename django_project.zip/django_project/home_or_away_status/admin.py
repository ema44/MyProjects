from django.contrib import admin
from .models import HomeOrAwayStatus

admin.site.register(HomeOrAwayStatus)
