from django.apps import AppConfig


class GameStatusConfig(AppConfig):
    name = 'game_status'
