from django.apps import AppConfig


class StadiumConfig(AppConfig):
    name = 'stadium'
