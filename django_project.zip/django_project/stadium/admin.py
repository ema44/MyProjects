from django.contrib import admin
from .models import Stadium

admin.site.register(Stadium)
