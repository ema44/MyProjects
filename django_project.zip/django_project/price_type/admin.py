from django.contrib import admin
from .models import PriceType

admin.site.register(PriceType)
