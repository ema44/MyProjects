from django.apps import AppConfig


class PriceTypeConfig(AppConfig):
    name = 'price_type'
