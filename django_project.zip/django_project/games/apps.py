from django.apps import AppConfig


class GamesConfig(AppConfig):
    name = 'games'
